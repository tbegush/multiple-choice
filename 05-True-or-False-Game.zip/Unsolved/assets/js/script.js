// TODO: Create an array with five question objects

// TODO: Create a variable to keep track of the score

// TODO: Iterate over the questions array and display each question in a confirmation box

// TODO: Check the user's answer against the correct answer

// TODO: Alert the user if they are correct or wrong. Increment the score accordingly

// TODO: At the end of the game, alert the user with the final score
