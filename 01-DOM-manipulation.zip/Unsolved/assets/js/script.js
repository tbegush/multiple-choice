// Create your HTML Page via DOM Methods here!

var body = document.body;

// TODO: Add a centered h1

// TODO: Add a centered h2

// TODO: Add a centered image with a centered caption under it

// TODO: Add a list of your favorite foods (or other favorites)
